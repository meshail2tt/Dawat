# دعواتي 💌 — منصة الدعوات الرقمية

## 🗂️ هيكل المشروع
```
pages/
  index.js           ← تسجيل / دخول
  create.js          ← إنشاء دعوة
  dashboard/         ← داشبورد المستخدم
  admin/             ← داشبورد المدير
  i/[code].js        ← صفحة الدعوة للمدعو (رابط مختصر)
  api/
    auth/register    ← تسجيل يوزر
    auth/login       ← دخول يوزر
    invitations/     ← إنشاء / جلب دعوات
    rsvp/submit      ← رد المدعو
    admin/data       ← بيانات المدير
```

---

## 🚀 الإعداد (خطوة بخطوة)

### 1. Supabase
1. اذهب إلى [supabase.com](https://supabase.com) وأنشئ مشروع
2. اذهب إلى **SQL Editor** والصق محتوى ملف `supabase-schema.sql` وشغّله
3. اذهب إلى **Project Settings → API** وانسخ:
   - `Project URL`
   - `anon public key`

### 2. متغيرات البيئة
افتح ملف `.env.local` وعدّله:
```
NEXT_PUBLIC_SUPABASE_URL=https://XXXXXXXX.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyXXXXXXXXXX
ADMIN_USERNAME=admin
ADMIN_PASSWORD=كلمة_سر_قوية
NEXT_PUBLIC_SITE_URL=https://dawati.netlify.app
```

### 3. تثبيت وتشغيل محلياً
```bash
npm install
npm run dev
# افتح: http://localhost:3000
```

### 4. الرفع على Netlify
```bash
npm run build
```
ثم:
1. اذهب [netlify.com](https://netlify.com)
2. **Add new site → Deploy manually**
3. اسحب مجلد المشروع كاملاً
4. أضف متغيرات البيئة في: **Site settings → Environment variables**

---

## 🔗 الروابط

| الصفحة | الرابط |
|--------|--------|
| الرئيسية | `/` |
| داشبورد المستخدم | `/dashboard` |
| إنشاء دعوة | `/create` |
| الدعوة | `/i/[كود]` |
| لوحة المدير | `/admin` |

---

## 🛠️ تطوير مستقبلي
- إرسال SMS عند تأكيد الحضور (Twilio)
- دفع إلكتروني للباقات المدفوعة
- تصدير قائمة الحضور PDF
- إشعارات للمضيف عند كل رد
