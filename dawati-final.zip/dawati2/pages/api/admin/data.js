import { supabase } from '../../../lib/supabase';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { username, password } = req.body;

  if (
    username !== process.env.ADMIN_USERNAME ||
    password !== process.env.ADMIN_PASSWORD
  ) return res.status(401).json({ error: 'بيانات المدير غير صحيحة' });

  // Fetch all data
  const { data: users }       = await supabase.from('users').select('id, name, email, phone, created_at').order('created_at', { ascending: false });
  const { data: invitations }  = await supabase.from('invitations').select('*, rsvps(status)').order('created_at', { ascending: false });
  const { data: rsvps }        = await supabase.from('rsvps').select('*').order('created_at', { ascending: false });

  const invitationsWithCounts = (invitations || []).map(inv => ({
    ...inv,
    attending: inv.rsvps?.filter(r => r.status === 'attending').length || 0,
    declined:  inv.rsvps?.filter(r => r.status === 'declined').length  || 0,
    total:     inv.rsvps?.length || 0,
  }));

  return res.status(200).json({
    users: users || [],
    invitations: invitationsWithCounts,
    rsvps: rsvps || [],
    stats: {
      totalUsers:       (users || []).length,
      totalInvitations: (invitations || []).length,
      totalRsvps:       (rsvps || []).length,
      totalAttending:   (rsvps || []).filter(r => r.status === 'attending').length,
      totalDeclined:    (rsvps || []).filter(r => r.status === 'declined').length,
    }
  });
}
