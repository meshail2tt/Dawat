import { supabase } from '../../../lib/supabase';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { invitation_id, guest_name, guest_phone, status } = req.body;

  if (!invitation_id || !guest_name || !guest_phone || !status)
    return res.status(400).json({ error: 'جميع الحقول مطلوبة' });

  // Prevent duplicate by phone
  const { data: existing } = await supabase
    .from('rsvps')
    .select('id, status')
    .eq('invitation_id', invitation_id)
    .eq('guest_phone', guest_phone)
    .single();

  if (existing) {
    // Update existing
    const { data, error } = await supabase
      .from('rsvps').update({ status, guest_name })
      .eq('id', existing.id).select().single();
    if (error) return res.status(500).json({ error: 'خطأ في التحديث' });
    return res.status(200).json({ rsvp: data, updated: true });
  }

  const { data, error } = await supabase.from('rsvps').insert({
    invitation_id, guest_name, guest_phone, status,
  }).select().single();

  if (error) return res.status(500).json({ error: 'خطأ في حفظ الرد' });
  return res.status(200).json({ rsvp: data, updated: false });
}
