import { supabase } from '../../../lib/supabase';

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash).toString(16);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { email, password } = req.body;

  const { data: user, error } = await supabase
    .from('users').select('*').eq('email', email).single();

  if (error || !user) return res.status(400).json({ error: 'البريد الإلكتروني غير مسجّل' });
  if (user.password_hash !== simpleHash(password))
    return res.status(400).json({ error: 'كلمة المرور غير صحيحة' });

  const { password_hash, ...safeUser } = user;
  return res.status(200).json({ user: safeUser });
}
