import { supabase } from '../../lib/supabase';

// simple hash (for production use bcrypt)
function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash).toString(16);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { name, email, phone, password } = req.body;

  if (!name || !email || !phone || !password)
    return res.status(400).json({ error: 'جميع الحقول مطلوبة' });

  // Check existing
  const { data: existing } = await supabase
    .from('users').select('id').eq('email', email).single();
  if (existing) return res.status(400).json({ error: 'البريد الإلكتروني مسجّل مسبقاً' });

  const { data, error } = await supabase.from('users').insert({
    name, email, phone,
    password_hash: simpleHash(password),
  }).select().single();

  if (error) return res.status(500).json({ error: 'خطأ في إنشاء الحساب' });

  const { password_hash, ...user } = data;
  return res.status(200).json({ user });
}
