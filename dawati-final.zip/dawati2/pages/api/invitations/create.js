import { supabase } from '../../../lib/supabase';
import { nanoid } from 'nanoid';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { user_id, type, name1, name2, event_date, event_time, venue, city, message, theme } = req.body;

  if (!user_id || !name1) return res.status(400).json({ error: 'بيانات ناقصة' });

  const short_code = nanoid(7); // e.g. "aB3dE7f"

  const { data, error } = await supabase.from('invitations').insert({
    user_id, short_code, type, name1, name2,
    event_date, event_time, venue, city, message, theme,
  }).select().single();

  if (error) return res.status(500).json({ error: 'خطأ في إنشاء الدعوة' });
  return res.status(200).json({ invitation: data });
}
