import { supabase } from '../../../lib/supabase';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).end();
  const { code } = req.query;

  const { data, error } = await supabase
    .from('invitations')
    .select('*, rsvps(id, guest_name, guest_phone, status, created_at)')
    .eq('short_code', code)
    .single();

  if (error || !data) return res.status(404).json({ error: 'الدعوة غير موجودة' });
  return res.status(200).json({ invitation: data });
}
