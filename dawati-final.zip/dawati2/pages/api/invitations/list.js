import { supabase } from '../../../lib/supabase';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).end();
  const { user_id } = req.query;
  if (!user_id) return res.status(400).json({ error: 'user_id مطلوب' });

  const { data, error } = await supabase
    .from('invitations')
    .select('*, rsvps(status)')
    .eq('user_id', user_id)
    .order('created_at', { ascending: false });

  if (error) return res.status(500).json({ error: error.message });

  // Add counts
  const result = data.map(inv => ({
    ...inv,
    attending: inv.rsvps.filter(r => r.status === 'attending').length,
    declined:  inv.rsvps.filter(r => r.status === 'declined').length,
    total:     inv.rsvps.length,
  }));

  return res.status(200).json({ invitations: result });
}
