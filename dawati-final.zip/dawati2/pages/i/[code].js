import { useState } from 'react';
import Head from 'next/head';
import { supabase } from '../../lib/supabase';
import styles from '../../styles/Invite.module.css';

export async function getServerSideProps({ params }) {
  const { code } = params;
  const { data } = await supabase
    .from('invitations').select('*').eq('short_code', code).single();
  if (!data) return { notFound: true };

  // Format date & time nicely
  let displayDate = data.event_date || '';
  let displayTime = data.event_time || '';
  try {
    if (data.event_date) {
      displayDate = new Date(data.event_date).toLocaleDateString('ar-SA', { year:'numeric', month:'long', day:'numeric' });
    }
    if (data.event_time) {
      const [h, m] = data.event_time.split(':');
      const hour = parseInt(h);
      displayDate = displayDate;
      displayTime = `${hour % 12 || 12}:${m} ${hour >= 12 ? 'مساءً' : 'صباحاً'}`;
    }
  } catch {}

  return { props: { invitation: { ...data, displayDate, displayTime } } };
}

const THEME_STYLES = {
  gold: { bg: 'linear-gradient(145deg,#1A1208,#2E1F08)', accent: '#E8C97A' },
  blue: { bg: 'linear-gradient(145deg,#0D1F2D,#1a3a52)', accent: '#7EC8E3' },
  rose: { bg: 'linear-gradient(145deg,#1F0D1A,#3a1a32)', accent: '#E87EC8' },
};

export default function InvitePage({ invitation: inv }) {
  const [step, setStep] = useState('view'); // view | form | done
  const [choice, setChoice] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [guestForm, setGuestForm] = useState({ name: '', phone: '' });

  const theme = THEME_STYLES[inv.theme] || THEME_STYLES.gold;
  const isWedding = inv.type === 'زفاف' || inv.type === 'خطوبة';

  const setG = (k, v) => setGuestForm(p => ({ ...p, [k]: v }));

  const handleRSVP = (status) => {
    setChoice(status);
    setStep('form');
  };

  const submitRSVP = async () => {
    if (!guestForm.name || !guestForm.phone) return setError('الرجاء تعبئة الاسم ورقم الجوال');
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/rsvp/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invitation_id: inv.id, guest_name: guestForm.name, guest_phone: guestForm.phone, status: choice }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setStep('done');
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  return (
    <>
      <Head>
        <title>دعوة {inv.type} — {inv.name1}</title>
        <meta name="og:title" content={`دعوة ${inv.type} — ${inv.name1}`} />
      </Head>
      <div className={styles.page}>
        <div className={styles.card}>

          {/* Header */}
          <div className={styles.header} style={{ background: theme.bg }}>
            <div className={styles.pattern} />
            <div className={styles.ornament} style={{ color: theme.accent }}>✦ ✦ ✦</div>
            <div className={styles.bismillah} style={{ color: theme.accent }}>بسم الله الرحمن الرحيم</div>
            <div className={styles.eventType}>حفل {inv.type}</div>
          </div>

          <div className={styles.goldBar} style={{ background: `linear-gradient(90deg,transparent,${theme.accent},transparent)` }} />

          {/* Body */}
          <div className={styles.body}>
            {step === 'view' && (
              <>
                <p className={styles.announce}>يسعدنا دعوتكم الكرام لحضور</p>
                <div className={styles.names}>
                  <span>{inv.name1}</span>
                  {isWedding && inv.name2 && (
                    <><span className={styles.amp} style={{ color: theme.accent }}>&amp;</span><span>{inv.name2}</span></>
                  )}
                </div>
                {inv.message && <p className={styles.message}>{inv.message}</p>}

                <div className={styles.details}>
                  {inv.displayDate && <div className={styles.detailBox}><span>📅</span><span className={styles.dLabel}>التاريخ</span><strong>{inv.displayDate}</strong></div>}
                  {inv.displayTime && <div className={styles.detailBox}><span>🕗</span><span className={styles.dLabel}>الوقت</span><strong>{inv.displayTime}</strong></div>}
                  {inv.venue && <div className={styles.detailBox}><span>📍</span><span className={styles.dLabel}>القاعة</span><strong>{inv.venue}</strong></div>}
                  {inv.city && <div className={styles.detailBox}><span>🏙️</span><span className={styles.dLabel}>المدينة</span><strong>{inv.city}</strong></div>}
                </div>

                <div className={styles.rsvpSection}>
                  <p className={styles.rsvpTitle}>هل ستحضر؟</p>
                  <div className={styles.rsvpBtns}>
                    <button className={`${styles.rsvpBtn} ${styles.accept}`} onClick={() => handleRSVP('attending')}>✓ سأحضر بإذن الله</button>
                    <button className={`${styles.rsvpBtn} ${styles.decline}`} onClick={() => handleRSVP('declined')}>✗ أعتذر</button>
                  </div>
                </div>
              </>
            )}

            {step === 'form' && (
              <div className={styles.guestForm}>
                <div className={styles.choiceBadge} style={{ background: choice==='attending' ? '#f0fff4' : '#fff5f5', color: choice==='attending' ? 'var(--green)' : 'var(--red)', border: `1px solid ${choice==='attending' ? '#c6f6d5' : '#fed7d7'}` }}>
                  {choice === 'attending' ? '✅ اخترت الحضور' : '❌ اخترت الاعتذار'}
                </div>
                <p className={styles.formTitle}>سجّل بياناتك</p>
                <div className={styles.fields}>
                  <div className={styles.field}>
                    <label>اسمك الكامل</label>
                    <input className="input-field" placeholder="محمد العمري" value={guestForm.name} onChange={e => setG('name', e.target.value)} />
                  </div>
                  <div className={styles.field}>
                    <label>رقم جوالك</label>
                    <input className="input-field" placeholder="05XXXXXXXX" value={guestForm.phone} onChange={e => setG('phone', e.target.value)} />
                  </div>
                </div>
                {error && <div className="error-msg">{error}</div>}
                <div className={styles.formBtns}>
                  <button className="btn-secondary" onClick={() => setStep('view')}>→ رجوع</button>
                  <button className="btn-primary" onClick={submitRSVP} disabled={loading}>
                    {loading ? <span className="spinner" /> : 'تأكيد'}
                  </button>
                </div>
              </div>
            )}

            {step === 'done' && (
              <div className={styles.doneBox}>
                <div className={styles.doneIcon}>{choice === 'attending' ? '🎉' : '🤍'}</div>
                <h2 className={styles.doneTitle}>
                  {choice === 'attending' ? 'شكراً! تم تأكيد حضورك' : 'تم تسجيل اعتذارك'}
                </h2>
                <p className={styles.doneDesc}>
                  {choice === 'attending'
                    ? `نسعد بحضورك في ${inv.displayDate || 'المناسبة'}${inv.venue ? ` في ${inv.venue}` : ''}`
                    : 'شكراً على إعلامنا، نتمنى نراك في مناسبات قادمة'}
                </p>
              </div>
            )}
          </div>

          <div className={styles.footer}>✦ دعواتي — منصة الدعوات الرقمية ✦</div>
        </div>
      </div>
    </>
  );
}
