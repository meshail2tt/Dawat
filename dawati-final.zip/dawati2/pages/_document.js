import { Html, Head, Main, NextScript } from 'next/document';
export default function Document() {
  return (
    <Html lang="ar" dir="rtl">
      <Head>
        <meta charSet="utf-8" />
        <meta name="description" content="دعواتي — منصة الدعوات الرقمية الذكية" />
      </Head>
      <body><Main /><NextScript /></body>
    </Html>
  );
}
