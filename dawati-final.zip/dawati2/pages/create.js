import { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import Link from 'next/link';
import styles from '../styles/Create.module.css';

const THEMES = [
  { id: 'gold', label: '🌙 ذهبي', bg: 'linear-gradient(135deg,#1A1208,#2E1F08)', color: '#E8C97A' },
  { id: 'blue', label: '💙 أزرق', bg: 'linear-gradient(135deg,#0D1F2D,#1a3a52)', color: '#7EC8E3' },
  { id: 'rose', label: '🌸 وردي', bg: 'linear-gradient(135deg,#1F0D1A,#3a1a32)', color: '#E87EC8' },
];
const TYPES = ['زفاف','خطوبة','تخرج','عيد ميلاد','عقيقة','مناسبة عامة'];

export default function CreatePage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ type:'زفاف', name1:'', name2:'', event_date:'', event_time:'', venue:'', city:'', message:'يسعدنا دعوتكم الكرام لحضور هذه المناسبة السعيدة', theme:'gold' });

  useEffect(() => {
    const u = localStorage.getItem('dawati_user');
    if (!u) router.push('/');
    else setUser(JSON.parse(u));
  }, []);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const isWedding = form.type === 'زفاف' || form.type === 'خطوبة';

  const handleCreate = async () => {
    if (!form.name1) return setError('الرجاء إدخال الاسم');
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/invitations/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, user_id: user.id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      router.push('/dashboard');
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  return (
    <>
      <Head><title>دعوة جديدة — دعواتي</title></Head>
      <div className={styles.page}>
        <div className={styles.topbar}>
          <Link href="/dashboard" className={styles.back}>→ العودة</Link>
          <span className={styles.topTitle}>إنشاء دعوة جديدة</span>
        </div>

        <div className={styles.container}>
          {/* Steps */}
          <div className={styles.steps}>
            {['التصميم','البيانات','التفاصيل'].map((s,i) => (
              <div key={s} className={`${styles.step} ${step > i+1 ? styles.done : ''} ${step === i+1 ? styles.current : ''}`}>
                <div className={styles.stepDot}>{step > i+1 ? '✓' : i+1}</div>
                <span>{s}</span>
              </div>
            ))}
          </div>

          {/* Step 1: Theme */}
          {step === 1 && (
            <div className={`${styles.card} fadeUp`}>
              <h2 className={styles.cardTitle}>🎨 اختر تصميم الدعوة</h2>
              <div className={styles.themeGrid}>
                {THEMES.map(t => (
                  <div key={t.id} className={`${styles.themeCard} ${form.theme===t.id?styles.selectedTheme:''}`}
                    style={{background:t.bg, color:t.color}} onClick={() => set('theme', t.id)}>
                    <span style={{fontSize:28, marginBottom:8, display:'block'}}>✦</span>
                    {t.label}
                    {form.theme===t.id && <div className={styles.checkmark}>✓</div>}
                  </div>
                ))}
              </div>
              <button className="btn-primary" onClick={() => setStep(2)}>التالي ←</button>
            </div>
          )}

          {/* Step 2: Names */}
          {step === 2 && (
            <div className={`${styles.card} fadeUp`}>
              <h2 className={styles.cardTitle}>📋 بيانات المناسبة</h2>
              <div className={styles.fields}>
                <div className={styles.field}>
                  <label>نوع المناسبة</label>
                  <select className="input-field" value={form.type} onChange={e => set('type', e.target.value)}>
                    {TYPES.map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className={styles.field}>
                  <label>{isWedding ? 'اسم العريس' : 'الاسم الكامل'}</label>
                  <input className="input-field" placeholder="أحمد بن خالد" value={form.name1} onChange={e => set('name1', e.target.value)} />
                </div>
                {isWedding && (
                  <div className={styles.field}>
                    <label>اسم العروس</label>
                    <input className="input-field" placeholder="سارة بنت محمد" value={form.name2} onChange={e => set('name2', e.target.value)} />
                  </div>
                )}
                <div className={styles.field}>
                  <label>رسالة الدعوة</label>
                  <textarea className="input-field" style={{height:90, resize:'none'}} value={form.message} onChange={e => set('message', e.target.value)} />
                </div>
              </div>
              <div className={styles.navBtns}>
                <button className="btn-secondary" onClick={() => setStep(1)}>→ السابق</button>
                <button className="btn-primary" onClick={() => form.name1 ? setStep(3) : setError('أدخل الاسم')}>التالي ←</button>
              </div>
              {error && <div className="error-msg" style={{marginTop:12}}>{error}</div>}
            </div>
          )}

          {/* Step 3: Date & Place */}
          {step === 3 && (
            <div className={`${styles.card} fadeUp`}>
              <h2 className={styles.cardTitle}>📅 التاريخ والمكان</h2>
              <div className={styles.fields}>
                <div className={styles.row}>
                  <div className={styles.field}>
                    <label>التاريخ</label>
                    <input className="input-field" type="date" value={form.event_date} onChange={e => set('event_date', e.target.value)} />
                  </div>
                  <div className={styles.field}>
                    <label>الوقت</label>
                    <input className="input-field" type="time" value={form.event_time} onChange={e => set('event_time', e.target.value)} />
                  </div>
                </div>
                <div className={styles.row}>
                  <div className={styles.field}>
                    <label>القاعة / المكان</label>
                    <input className="input-field" placeholder="قاعة الأميرة" value={form.venue} onChange={e => set('venue', e.target.value)} />
                  </div>
                  <div className={styles.field}>
                    <label>المدينة</label>
                    <input className="input-field" placeholder="الرياض" value={form.city} onChange={e => set('city', e.target.value)} />
                  </div>
                </div>
              </div>
              {error && <div className="error-msg" style={{marginBottom:12}}>{error}</div>}
              <div className={styles.navBtns}>
                <button className="btn-secondary" onClick={() => setStep(2)}>→ السابق</button>
                <button className="btn-primary" onClick={handleCreate} disabled={loading}>
                  {loading ? <span className="spinner" /> : '🚀 إنشاء الدعوة'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
