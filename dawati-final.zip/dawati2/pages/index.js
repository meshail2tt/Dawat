import { useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import styles from '../styles/Auth.module.css';

export default function Home() {
  const router = useRouter();
  const [mode, setMode] = useState('register'); // register | login
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' });

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSubmit = async () => {
    setError('');
    if (!form.email || !form.password) return setError('الرجاء تعبئة جميع الحقول');
    if (mode === 'register' && (!form.name || !form.phone)) return setError('الرجاء تعبئة جميع الحقول');

    setLoading(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'حدث خطأ');
      localStorage.setItem('dawati_user', JSON.stringify(data.user));
      router.push('/dashboard');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Head><title>دعواتي — منصة الدعوات الرقمية</title></Head>
      <div className={styles.page}>

        {/* Hero side */}
        <div className={styles.hero}>
          <div className={styles.heroContent}>
            <div className={styles.logo}>✦ دعواتي</div>
            <h1 className={styles.heroTitle}>دعواتك الرقمية<br />بلمسة فاخرة</h1>
            <p className={styles.heroDesc}>أنشئ دعوتك، شاركها عبر واتساب، وتابع ردود مدعوييك لحظة بلحظة</p>
            <div className={styles.features}>
              {['💌 دعوات أنيقة', '✅ تأكيد الحضور', '📊 إحصائيات فورية', '📤 مشاركة واتساب'].map(f => (
                <span key={f} className={styles.feature}>{f}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Auth side */}
        <div className={styles.authSide}>
          <div className={styles.authBox}>
            <div className={styles.authTabs}>
              <button className={`${styles.authTab} ${mode === 'register' ? styles.activeTab : ''}`} onClick={() => { setMode('register'); setError(''); }}>
                حساب جديد
              </button>
              <button className={`${styles.authTab} ${mode === 'login' ? styles.activeTab : ''}`} onClick={() => { setMode('login'); setError(''); }}>
                تسجيل دخول
              </button>
            </div>

            <div className={styles.fields}>
              {mode === 'register' && (
                <>
                  <div className={styles.fieldGroup}>
                    <label>الاسم الكامل</label>
                    <input className="input-field" placeholder="محمد العمري" value={form.name} onChange={e => set('name', e.target.value)} />
                  </div>
                  <div className={styles.fieldGroup}>
                    <label>رقم الجوال</label>
                    <input className="input-field" placeholder="05XXXXXXXX" value={form.phone} onChange={e => set('phone', e.target.value)} />
                  </div>
                </>
              )}
              <div className={styles.fieldGroup}>
                <label>البريد الإلكتروني</label>
                <input className="input-field" type="email" placeholder="example@email.com" value={form.email} onChange={e => set('email', e.target.value)} />
              </div>
              <div className={styles.fieldGroup}>
                <label>كلمة المرور</label>
                <input className="input-field" type="password" placeholder="••••••••" value={form.password} onChange={e => set('password', e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
              </div>

              {error && <div className="error-msg">{error}</div>}

              <button className="btn-primary" onClick={handleSubmit} disabled={loading}>
                {loading ? <span className="spinner" /> : mode === 'register' ? '✨ إنشاء حساب' : 'دخول →'}
              </button>
            </div>
          </div>
        </div>

      </div>
    </>
  );
}
