import { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import Link from 'next/link';
import styles from '../../styles/Dashboard.module.css';

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [invitations, setInvitations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState(null);

  useEffect(() => {
    const u = localStorage.getItem('dawati_user');
    if (!u) return router.push('/');
    const parsed = JSON.parse(u);
    setUser(parsed);
    fetchInvitations(parsed.id);
  }, []);

  const fetchInvitations = async (userId) => {
    const res = await fetch(`/api/invitations/list?user_id=${userId}`);
    const data = await res.json();
    setInvitations(data.invitations || []);
    setLoading(false);
  };

  const copyLink = (code) => {
    const url = `${window.location.origin}/i/${code}`;
    navigator.clipboard?.writeText(url);
    setCopiedId(code);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const shareWhatsapp = (inv) => {
    const url = `${window.location.origin}/i/${inv.short_code}`;
    const text = `🎊 دعوة ${inv.type}\n\n${inv.name1}${inv.name2 ? ` & ${inv.name2}` : ''}\n\n📅 ${inv.event_date || ''}\n📍 ${inv.venue || ''}، ${inv.city || ''}\n\n${url}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const logout = () => { localStorage.removeItem('dawati_user'); router.push('/'); };

  if (loading) return <div className={styles.loading}><span className="spinner" style={{borderTopColor:'var(--gold)',borderColor:'var(--gold-pale)'}} /></div>;

  const totalAttending = invitations.reduce((s, i) => s + i.attending, 0);
  const totalDeclined  = invitations.reduce((s, i) => s + i.declined, 0);

  return (
    <>
      <Head><title>لوحة التحكم — دعواتي</title></Head>
      <div className={styles.page}>

        {/* Sidebar */}
        <aside className={styles.sidebar}>
          <div className={styles.sidebarLogo}>✦ دعواتي</div>
          <nav className={styles.nav}>
            <span className={`${styles.navItem} ${styles.active}`}>🏠 دعواتي</span>
            <Link href="/create" className={styles.navItem}>➕ دعوة جديدة</Link>
          </nav>
          <div className={styles.sidebarUser}>
            <div className={styles.userAvatar}>{user?.name?.[0]}</div>
            <div>
              <div className={styles.userName}>{user?.name}</div>
              <div className={styles.userEmail}>{user?.email}</div>
            </div>
          </div>
          <button className={styles.logoutBtn} onClick={logout}>خروج</button>
        </aside>

        {/* Main */}
        <main className={styles.main}>
          <div className={styles.header}>
            <h1 className={styles.title}>مرحباً، {user?.name?.split(' ')[0]} 👋</h1>
            <Link href="/create" className="btn-primary" style={{width:'auto', padding:'10px 20px'}}>
              ➕ دعوة جديدة
            </Link>
          </div>

          {/* Stats */}
          <div className={styles.statsGrid}>
            <div className={styles.statCard}>
              <div className={styles.statNum}>{invitations.length}</div>
              <div className={styles.statLabel}>إجمالي الدعوات</div>
            </div>
            <div className={styles.statCard} style={{borderColor:'#c6f6d5'}}>
              <div className={styles.statNum} style={{color:'var(--green)'}}>{totalAttending}</div>
              <div className={styles.statLabel}>إجمالي الحاضرين</div>
            </div>
            <div className={styles.statCard} style={{borderColor:'#fed7d7'}}>
              <div className={styles.statNum} style={{color:'var(--red)'}}>{totalDeclined}</div>
              <div className={styles.statLabel}>إجمالي الاعتذارات</div>
            </div>
          </div>

          {/* Invitations */}
          {invitations.length === 0 ? (
            <div className={styles.empty}>
              <div className={styles.emptyIcon}>💌</div>
              <p>ما عندك دعوات بعد</p>
              <Link href="/create" className="btn-primary" style={{width:'200px',marginTop:'16px'}}>إنشاء أول دعوة</Link>
            </div>
          ) : (
            <div className={styles.invList}>
              {invitations.map(inv => (
                <div key={inv.id} className={styles.invCard}>
                  <div className={styles.invHeader}>
                    <div>
                      <div className={styles.invType}>{inv.type}</div>
                      <div className={styles.invName}>{inv.name1}{inv.name2 ? ` & ${inv.name2}` : ''}</div>
                      <div className={styles.invMeta}>
                        {inv.event_date && <span>📅 {inv.event_date}</span>}
                        {inv.venue && <span>📍 {inv.venue}</span>}
                      </div>
                    </div>
                    <div className={styles.invCode}>#{inv.short_code}</div>
                  </div>

                  {/* RSVP bar */}
                  <div className={styles.rsvpBar}>
                    <div className={styles.rsvpStat}>
                      <span className={styles.rsvpNum} style={{color:'var(--green)'}}>{inv.attending}</span>
                      <span className={styles.rsvpLbl}>✅ حاضر</span>
                    </div>
                    <div className={styles.rsvpStat}>
                      <span className={styles.rsvpNum} style={{color:'var(--red)'}}>{inv.declined}</span>
                      <span className={styles.rsvpLbl}>❌ اعتذر</span>
                    </div>
                    <div className={styles.rsvpStat}>
                      <span className={styles.rsvpNum}>{inv.total}</span>
                      <span className={styles.rsvpLbl}>📊 الكل</span>
                    </div>
                  </div>

                  {/* Progress */}
                  {inv.total > 0 && (
                    <div className={styles.progressBar}>
                      <div className={styles.progressFill} style={{width:`${(inv.attending/inv.total)*100}%`}} />
                    </div>
                  )}

                  {/* Actions */}
                  <div className={styles.invActions}>
                    <button className={styles.actionBtn} onClick={() => shareWhatsapp(inv)}>📤 واتساب</button>
                    <button className={styles.actionBtn} onClick={() => copyLink(inv.short_code)}>
                      {copiedId === inv.short_code ? '✓ تم' : '🔗 الرابط'}
                    </button>
                    <Link href={`/i/${inv.short_code}`} className={styles.actionBtn} target="_blank">👁 معاينة</Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </>
  );
}
