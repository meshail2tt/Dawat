import { useState } from 'react';
import Head from 'next/head';
import styles from '../../styles/Admin.module.css';

export default function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [creds, setCreds] = useState({ username: '', password: '' });
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  const login = async () => {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/admin/data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(creds),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);
      setData(json);
      setAuthed(true);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  if (!authed) return (
    <>
      <Head><title>المدير — دعواتي</title></Head>
      <div className={styles.loginPage}>
        <div className={styles.loginBox}>
          <div className={styles.adminLogo}>🔐 لوحة المدير</div>
          <div className={styles.fields}>
            <input className="input-field" placeholder="اسم المستخدم" value={creds.username} onChange={e => setCreds(p=>({...p,username:e.target.value}))} />
            <input className="input-field" type="password" placeholder="كلمة المرور" value={creds.password} onChange={e => setCreds(p=>({...p,password:e.target.value}))} onKeyDown={e=>e.key==='Enter'&&login()} />
            {error && <div className="error-msg">{error}</div>}
            <button className="btn-primary" onClick={login} disabled={loading}>
              {loading ? <span className="spinner"/> : 'دخول →'}
            </button>
          </div>
        </div>
      </div>
    </>
  );

  const { stats, users, invitations, rsvps } = data;

  return (
    <>
      <Head><title>لوحة المدير — دعواتي</title></Head>
      <div className={styles.page}>

        {/* Sidebar */}
        <aside className={styles.sidebar}>
          <div className={styles.logo}>⚙️ المدير</div>
          <nav className={styles.nav}>
            {[['overview','📊 نظرة عامة'],['users','👥 المستخدمون'],['invitations','💌 الدعوات'],['rsvps','✅ الردود']].map(([id,lbl])=>(
              <button key={id} className={`${styles.navItem} ${activeTab===id?styles.active:''}`} onClick={()=>setActiveTab(id)}>{lbl}</button>
            ))}
          </nav>
          <button className={styles.logoutBtn} onClick={()=>setAuthed(false)}>خروج</button>
        </aside>

        <main className={styles.main}>
          {/* Overview */}
          {activeTab === 'overview' && (
            <div className="fadeUp">
              <h1 className={styles.pageTitle}>نظرة عامة</h1>
              <div className={styles.statsGrid}>
                {[
                  { num: stats.totalUsers, lbl: 'مستخدم مسجّل', color: 'var(--gold)', bg: 'var(--gold-pale)' },
                  { num: stats.totalInvitations, lbl: 'دعوة منشورة', color: '#6B46C1', bg: '#FAF5FF' },
                  { num: stats.totalAttending, lbl: 'تأكيد حضور', color: 'var(--green)', bg: '#F0FFF4' },
                  { num: stats.totalDeclined, lbl: 'اعتذار', color: 'var(--red)', bg: '#FFF5F5' },
                ].map(s => (
                  <div key={s.lbl} className={styles.statCard} style={{ borderColor: s.color + '33', background: s.bg }}>
                    <div className={styles.statNum} style={{ color: s.color }}>{s.num}</div>
                    <div className={styles.statLbl}>{s.lbl}</div>
                  </div>
                ))}
              </div>

              {/* Recent invitations */}
              <h2 className={styles.sectionTitle}>آخر الدعوات</h2>
              <div className={styles.table}>
                <div className={`${styles.tableRow} ${styles.tableHead}`}>
                  <span>الدعوة</span><span>النوع</span><span>التاريخ</span><span>حضور</span><span>اعتذار</span>
                </div>
                {invitations.slice(0,5).map(inv => (
                  <div key={inv.id} className={styles.tableRow}>
                    <span>{inv.name1}{inv.name2?` & ${inv.name2}`:''}</span>
                    <span><span className={styles.badge}>{inv.type}</span></span>
                    <span>{inv.event_date||'—'}</span>
                    <span className={styles.green}>{inv.attending}</span>
                    <span className={styles.red}>{inv.declined}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Users */}
          {activeTab === 'users' && (
            <div className="fadeUp">
              <h1 className={styles.pageTitle}>المستخدمون ({users.length})</h1>
              <div className={styles.table}>
                <div className={`${styles.tableRow} ${styles.tableHead}`}>
                  <span>الاسم</span><span>البريد</span><span>الجوال</span><span>تاريخ التسجيل</span>
                </div>
                {users.map(u => (
                  <div key={u.id} className={styles.tableRow}>
                    <span className={styles.bold}>{u.name}</span>
                    <span>{u.email}</span>
                    <span>{u.phone}</span>
                    <span className={styles.muted}>{new Date(u.created_at).toLocaleDateString('ar-SA')}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Invitations */}
          {activeTab === 'invitations' && (
            <div className="fadeUp">
              <h1 className={styles.pageTitle}>الدعوات ({invitations.length})</h1>
              <div className={styles.table}>
                <div className={`${styles.tableRow} ${styles.tableHead}`}>
                  <span>الدعوة</span><span>الكود</span><span>المناسبة</span><span>المكان</span><span>حضور</span><span>اعتذار</span>
                </div>
                {invitations.map(inv => (
                  <div key={inv.id} className={styles.tableRow}>
                    <span className={styles.bold}>{inv.name1}{inv.name2?` & ${inv.name2}`:''}</span>
                    <span><code className={styles.code}>{inv.short_code}</code></span>
                    <span>{inv.type}</span>
                    <span>{inv.venue||'—'}{inv.city?`, ${inv.city}`:''}</span>
                    <span className={styles.green}>{inv.attending}</span>
                    <span className={styles.red}>{inv.declined}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* RSVPs */}
          {activeTab === 'rsvps' && (
            <div className="fadeUp">
              <h1 className={styles.pageTitle}>الردود ({rsvps.length})</h1>
              <div className={styles.table}>
                <div className={`${styles.tableRow} ${styles.tableHead}`}>
                  <span>اسم المدعو</span><span>الجوال</span><span>الرد</span><span>التاريخ</span>
                </div>
                {rsvps.map(r => (
                  <div key={r.id} className={styles.tableRow}>
                    <span className={styles.bold}>{r.guest_name}</span>
                    <span>{r.guest_phone}</span>
                    <span>
                      <span className={`${styles.statusBadge} ${r.status==='attending'?styles.statusGreen:styles.statusRed}`}>
                        {r.status==='attending'?'✅ حاضر':'❌ اعتذر'}
                      </span>
                    </span>
                    <span className={styles.muted}>{new Date(r.created_at).toLocaleDateString('ar-SA')}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </>
  );
}
