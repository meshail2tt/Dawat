-- =============================================
-- دعواتي — Supabase Database Schema
-- شغّل هذا الكود في: Supabase → SQL Editor
-- =============================================

-- جدول المستخدمين (أصحاب الدعوات)
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text unique not null,
  phone text not null,
  password_hash text not null,
  created_at timestamptz default now()
);

-- جدول الدعوات
create table if not exists invitations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  short_code text unique not null,
  type text not null default 'زفاف',
  name1 text not null,
  name2 text,
  event_date text,
  event_time text,
  venue text,
  city text,
  message text,
  theme text default 'gold',
  created_at timestamptz default now()
);

-- جدول ردود المدعوين
create table if not exists rsvps (
  id uuid primary key default gen_random_uuid(),
  invitation_id uuid references invitations(id) on delete cascade,
  guest_name text not null,
  guest_phone text not null,
  status text not null check (status in ('attending', 'declined')),
  created_at timestamptz default now()
);

-- فهارس للسرعة
create index if not exists invitations_user_id_idx on invitations(user_id);
create index if not exists invitations_short_code_idx on invitations(short_code);
create index if not exists rsvps_invitation_id_idx on rsvps(invitation_id);

-- تعطيل RLS (للتطوير السريع — شغّله لاحقاً للأمان)
alter table users disable row level security;
alter table invitations disable row level security;
alter table rsvps disable row level security;
